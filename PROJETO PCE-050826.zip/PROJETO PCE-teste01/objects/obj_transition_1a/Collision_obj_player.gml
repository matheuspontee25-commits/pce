global.spawn_x = spawn_x;
global.spawn_y = spawn_y;

room_goto(target_room);