target_room = rm_floresta;

spawn_x = 64;
spawn_y = 320;
