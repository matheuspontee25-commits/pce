target_room = rm_sala;

spawn_x = 920;
spawn_y = 320;
