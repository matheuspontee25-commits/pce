//ler o teclado

var right = keyboard_check(ord("D"));
var left = keyboard_check(ord("A"));
var down = keyboard_check(ord("S"));
var up = keyboard_check(ord("W"));

//calcula a direção

hsp = (right - left) * walk_speed;
vsp = (down - up) * walk_speed;

//colisão horizontal

x += hsp;

if (place_meeting(x, y, obj_solid))
{
	x -= hsp;
}

//colisão vertical

y += vsp;

if (place_meeting(x, y, obj_solid))
{
	y -= vsp;
}

//direção de onde o jogador está olhando

if (hsp > 0)
facing = "right"

if (hsp < 0)
facing = "left";

if (vsp > 0)
facing = "down";

if (vsp < 0)
facing = "up";

//muda o sprite da direção de onde ele tá olhando

switch(facing)
{
	case "down":
	sprite_index = spr_player_down;
	break;
	
	case "up":
	sprite_index = spr_player_up;
	break;
	
	case "left":
	sprite_index = spr_player_left;
	break;
	
	case "right":
	sprite_index = spr_player_right;
	break;
}

//animação pra andar

if (hsp == 0 && vsp ==0)
{
	image_speed = 0;
	image_index = 0;
}
else
{
	image_speed = 0.1;
}
