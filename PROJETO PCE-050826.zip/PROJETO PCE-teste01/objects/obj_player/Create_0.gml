//velocidade de movimento

walk_speed = 3;

//movimento

hsp = 0;
vsp = 0;

//direção pra onde o caba tá olhando

facing = "down";
