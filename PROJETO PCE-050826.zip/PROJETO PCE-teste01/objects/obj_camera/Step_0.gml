if (instance_exists(target))
{
	var cam = view_camera[0];
	
	var cx = camera_get_view_x(cam);
	var cy = camera_get_view_y(cam);
	
	var tx = target.x - camera_get_view_width(cam) / 2;
	var ty = target.y - camera_get_view_height(cam) / 2;
	
	cx = lerp(cx, tx, follow_speed);
	cy = lerp(cy, ty, follow_speed);
	
	camera_set_view_pos(cam, cx, cy);
}